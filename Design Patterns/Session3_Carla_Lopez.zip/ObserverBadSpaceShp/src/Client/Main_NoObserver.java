package Client;

import Publisher.SpacecraftTelemetry;
import SuscriptorConcreto.CurrentTelemetryDisplay;
import SuscriptorConcreto.NavigationStatisticsDisplay;
/*
public class Main_NoObserver {

    public static void main(String[] args) {

        SpacecraftTelemetry telemetry = new SpacecraftTelemetry();

        CurrentTelemetryDisplay currentDisplay = new CurrentTelemetryDisplay();
        NavigationStatisticsDisplay statisticsDisplay = new NavigationStatisticsDisplay();

        telemetry.setState(10.0, 20.0, 45.0, 100.0, 5.0);
        currentDisplay.update(telemetry);
        statisticsDisplay.update(telemetry);
        System.out.println();

        telemetry.setState(15.0, 22.0, 50.0, 120.0, 4.0);
        currentDisplay.update(telemetry);
        statisticsDisplay.update(telemetry);
        System.out.println();

        telemetry.setState(18.0, 30.0, 40.0, 90.0, 6.0);
        currentDisplay.update(telemetry);
        statisticsDisplay.update(telemetry);
    }
}*/