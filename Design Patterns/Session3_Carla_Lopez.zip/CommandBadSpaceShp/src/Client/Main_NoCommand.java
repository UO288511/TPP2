package Client;

import Receivers.StabilizerSystem;
import Receivers.ThrusterSystem;

public class Main_NoCommand {

    private ThrusterSystem thrusterSystem;
    private StabilizerSystem stabilizerSystem;

    public Main_NoCommand() {
        thrusterSystem = new ThrusterSystem();
        stabilizerSystem = new StabilizerSystem();
    }

    public void configureAccelerationNeeded() {
        System.out.println("=== Acceleration needed ===");
        thrusterSystem.increaseThrust();
        stabilizerSystem.increaseStabilization();
    }

    public void configureStabilityNeeded() {
        System.out.println("=== Stability needed ===");
        thrusterSystem.decreaseThrust();
        stabilizerSystem.increaseStabilization();
    }

    public static void main(String[] args) {
        Main_NoCommand application = new Main_NoCommand();

        application.configureAccelerationNeeded();
        System.out.println();

        application.configureStabilityNeeded();
    }
}