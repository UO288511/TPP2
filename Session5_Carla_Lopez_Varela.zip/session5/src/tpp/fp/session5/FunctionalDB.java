package tpp.fp.session5;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FunctionalDB {

	// Inner class for Employee data
	public static class Employee {
		private long id;
		private String name;
		private String department;
		private String role;
		private double salary;
		private int age;
		private int yearsAtCompany;
		private String city;
		private double performanceScore;

		public Employee(long id, String name, String department, String role, double salary, int age,
				int yearsAtCompany, String city, double performanceScore) {
			this.id = id;
			this.name = name;
			this.department = department;
			this.role = role;
			this.salary = salary;
			this.age = age;
			this.yearsAtCompany = yearsAtCompany;
			this.city = city;
			this.performanceScore = performanceScore;
		}

		// Getters
		public long getId() {
			return id;
		}

		public String getName() {
			return name;
		}

		public String getDepartment() {
			return department;
		}

		public String getRole() {
			return role;
		}

		public double getSalary() {
			return salary;
		}

		public int getAge() {
			return age;
		}

		public int getYearsAtCompany() {
			return yearsAtCompany;
		}

		public String getCity() {
			return city;
		}

		public double getPerformanceScore() {
			return performanceScore;
		}

		@Override
		public String toString() {
			return "Employee{" + "name='" + name + '\'' + ", dept='" + department + '\'' + ", role='" + role + '\''
					+ ", salary=" + salary + '}';
		}
	}

	public static void main(String[] args) {
		// 0. Load Data
		List<Employee> employees = loadEmployees("employees.csv");
		if (employees.isEmpty()) {
			System.out.println("No employees loaded. Check file path.");
			return;
		}
		System.out.println("Loaded " + employees.size() + " employees.");

		Scanner scanner = new Scanner(System.in);
		while (true) {
			printMenu();
			System.out.print("Choose an option: ");
			String input = scanner.nextLine();

			try {
				int option = Integer.parseInt(input);
				if (option == 0) {
					System.out.println("Exiting...");
					break;
				}

				switch (option) {
				case 1:
					showEmployeeDirectory(new ArrayList<>(employees)); // Pass a copy to avoid sorting the master list
																		// permanently
					break;
				case 2:
					showTalentRetention(employees);
					break;
				case 3:
					showCompensationAnalysis(employees);
					break;
				case 4:
					showHRAnalytics(employees);
					break;
				case 5:
					showDataQualityReport(employees);
					break;
				case 6: // Optional 1: Dynamic Filtering
					List<Predicate<Employee>> rules = new ArrayList<>();
					rules.add(e -> e.getSalary() > 50000);
					rules.add(e -> e.getDepartment().equals("IT"));
					filterEmployees(employees, rules);
					break;
				case 7: // Optional 2: Comparator Composition
					sortEmployeesComplex(new ArrayList<>(employees));
					break;
				case 8: // Optional 3: Average salary per Dept
					showAverSalaryDepartment(employees);
					break;
				default:
					System.out.println("Invalid option. Please try again.");
				}
			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Please enter a number.");
			}
			System.out.println("\nPress Enter to continue...");
			scanner.nextLine();
		}
		scanner.close();
	}

	private static void printMenu() {
		System.out.println("\n--------------------------------------------------");
		System.out.println("HR MANAGEMENT SYSTEM");
		System.out.println("--------------------------------------------------");
		System.out.println("1. Employee Directory (Sort by Name)");
		System.out.println("2. Talent Retention (Senior High-Performers)");
		System.out.println("3. Compensation (Bonus Calculations)");
		System.out.println("4. HR Analytics Dashboard");
		System.out.println("5. Data Quality Report");
		System.out.println("6. [Optional] Dynamic Filtering");
		System.out.println("7. [Optional] Complex Sorting Comp.");
		System.out.println("8. [Optional] Average salary per Dept");
		System.out.println("0. Exit");
		System.out.println("--------------------------------------------------");
	}

	// 1. Employee Directory (Sort by Name)
	private static void showEmployeeDirectory(List<Employee> employees) {
		System.out.println("\n--- 1. Employee Directory (Sorted by Name) ---");
		System.out.println("Sorting employees by name using Collections.sort() with a lambda expression...");

		// TODO Sort employees by name with a lambda expression
		employees.sort((a, b) -> a.getName().compareTo(b.getName()));
		employees.forEach(x->System.out.println(x));
	}

	// 2. Talent Retention (Senior High-Performers)
	private static void showTalentRetention(List<Employee> employees) {
		System.out.println("\n--- 2. Talent Retention (Senior High-Performers) ---");

		// TODO Show the name of the employees of the to 10 sorted in descending order
		// by performance score with a score equal or grater than 4.5 and more than 5
		// year at the company
		employees.stream()
				.filter(x->x.getPerformanceScore() >= 4.5)
				.filter(x-> x.getYearsAtCompany() > 5)
				.sorted((a,b) ->Double.compare(b.getPerformanceScore(), a.getPerformanceScore()))
				.limit(10)
				.map(x-> x.getName() )
				.forEach(x->System.out.println(x));
		

	}

	// 3. Compensation (Bonus Calculations)
	private static void showCompensationAnalysis(List<Employee> employees) {
		System.out.println("\n--- 3. Compensation (Bonus Calculations) ---");

		// TODO Show for the first 5 employees the name and the salary with a bonus of
		// 10% with the salary formatted as currency
		// NOTE: Use functional composition when possible
		Function<Employee, Double> baseSalary = e -> e.getSalary();
		Function<Double, Double> addBonus = s -> s * 1.10;

		
		Function <Employee, Double> composed = baseSalary.andThen(addBonus);
		
		employees.stream()
        .limit(5)
        .forEach(e -> System.out.println(
                	e.getName() + ": " + composed.apply(e)
        ));
		

	}

	// 4. HR Analytics Dashboard
	private static void showHRAnalytics(List<Employee> employees) {
		System.out.println("\n--- 4. HR Analytics Dashboard ---");

		// TODO Show:
		// 1st -> The name of all departments without duplicates
		employees.stream()
			.map(x->x.getDepartment())
			.distinct()
			.forEach(x->System.out.println(x));

		// 2nd -> Roles split into words without duplicates nor null or empty value in
		// upper case and sorted alphabetically
		employees.stream()
		    .map(Employee::getRole)
		    .filter(r -> r != null && !r.isBlank())		    
		    .map(String::toUpperCase)
		    .distinct()
		    .sorted()
		    .forEach(System.out::println);


		// 3rd -> The total amount of working experience of all employees
		int years = employees.stream()
			.mapToInt(x -> x.getYearsAtCompany())
			.sum();
		System.out.println("Total ammount of experience years: " + years);

		// 4th -> The employee with highest salary
		System.out.print("The employee with the highest salary is: ");
		employees.stream()
			.sorted((a,b) -> Double.compare(b.getSalary(), a.getSalary()))
			.limit(1)
			.forEach(System.out::println);
		//max(Comparator.comparingDouble(Employee::getSalary)) 
		

	}

	// 5. Data Quality Report
	private static void showDataQualityReport(List<Employee> employees) {
	    System.out.println("\n--- 5. Data Quality Report ---");
	    System.out.println("Identifying missing or invalid fields (marked as 0 or Unknown)...");

	    long missingSalaries = employees.stream()
	        .filter(e -> e.getSalary() == 0.0)
	        .count();

	    long missingAges = employees.stream()
	        .filter(e -> e.getAge() == 0)
	        .count();

	    long unknownDepts = employees.stream()
	        .filter(e -> "Unknown".equals(e.getDepartment()))
	        .count();

	    long unknownRoles = employees.stream()
	        .filter(e -> "Unknown".equals(e.getRole()))
	        .count();

	    System.out.println("----------------------------------------------");
	    System.out.printf("Missing Salaries  : %d%n", missingSalaries);
	    System.out.printf("Missing Ages      : %d%n", missingAges);
	    System.out.printf("Unknown Depts     : %d%n", unknownDepts);
	    System.out.printf("Unknown Roles     : %d%n", unknownRoles);
	    System.out.println("----------------------------------------------");
	    System.out.println("Total Issues found: " + 
	        (missingSalaries + missingAges + unknownDepts + unknownRoles));
	}


	// 6. [Optional] Dynamic Filtering (Combining Predicates with Reduce)
	private static void filterEmployees(List<Employee> employees, List<Predicate<Employee>> predicates) {
		System.out.println("\n--- 6. (Optional) Dynamic Filtering ---");

		// TODO Combine all the predicates with the and operator, filter the employees
		// based on the combined predicate and show the result
		Predicate<Employee> combined = predicates.stream()
												.reduce(x-> true,Predicate::and);
		employees.stream()
			.filter(combined)
			.forEach(System.out::println);

	}

	// 7. [Optional] Complex Sorting (Comparator composition)
	private static void sortEmployeesComplex(List<Employee> employees) {
		System.out.println("\n--- 7. (Optional) Complex Sorting ---");

		System.out.println("Sorting by Dept (ASC) -> Performance (DESC) -> Salary (DESC)...");

		// TODO Show the top 10 employees in ascending order by department, and in
		// descending order by performance and salary
		Comparator<Employee> compa =Comparator.comparing(Employee::getDepartment)
	            .thenComparing(Comparator.comparingDouble(Employee::getPerformanceScore).reversed())
	            .thenComparing(Comparator.comparingDouble(Employee::getSalary).reversed());
	
		 employees.stream()
         .sorted(compa)
         .limit(10)
         .forEach(System.out::println);

		

	}

	// 8. [Optional] Average salary per Department (Using GroupingBy)
	private static void showAverSalaryDepartment(List<Employee> employees) {
		System.out.println("\n--- 8. (Optional) Average salary per Department ---");

		// TODO Show the departments and their average salary in descending order by
		// salary
		employees.stream().collect(Collectors.toList());
		employees.stream().toList();
		Map<String, List<Employee>> employeesByDepartment= employees.stream().collect(Collectors.groupingBy(Employee::getDepartment));
		
		employeesByDepartment.forEach((department,list) -> {
			double avg = list.stream()
					.mapToDouble(Employee::getSalary)
					.average()
					.orElse(0);

			System.out.println(department + " -> " + avg);
		});

	}

	private static List<Employee> loadEmployees(String filePath) {
		List<Employee> list = new ArrayList<>();
		try (Stream<String> lines = Files.lines(Paths.get(filePath))) {
			// Skip header and parse
			list = lines.skip(1).map(line -> {
				String[] parts = line.split(",");
				// Handling potential empty strings if simple split is used,
				// but since we cleaned the CSV, we assume valid data.
				long id = Long.parseLong(parts[0]);
				String name = parts[1];
				String dept = parts[2];
				String role = parts[3];
				double salary = Double.parseDouble(parts[4]);
				int age = Integer.parseInt(parts[5]);
				int years = Integer.parseInt(parts[6]);
				String city = parts[7];
				double perf = Double.parseDouble(parts[8]);

				return new Employee(id, name, dept, role, salary, age, years, city, perf);
			}).collect(Collectors.toList());
		} catch (IOException e) {
			System.err.println("Error reading file: " + e.getMessage());
		} catch (NumberFormatException e) {
			System.err.println("Error parsing number: " + e.getMessage());
		}
		return list;
	}
}
