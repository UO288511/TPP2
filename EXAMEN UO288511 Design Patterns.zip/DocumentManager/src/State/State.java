package State;

public interface State {
	public void advance();
	public String name();
	
}
