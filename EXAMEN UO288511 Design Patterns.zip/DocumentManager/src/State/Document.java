package State;

import State.ConcreteStates.DraftState;

public class Document {
	private State s;
	public String name;

	public Document(State initialState) {
		super();
		initialState=new DraftState();
		this.s=initialState;
	}
	
	public void changeState(State state) {
		this.s=state;
	}
	
	public void advance() {
		s.advance();
	}
	
	
	
	
	

}
