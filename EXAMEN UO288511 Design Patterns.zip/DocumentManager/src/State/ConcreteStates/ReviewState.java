package State.ConcreteStates;

import State.Document;
import State.State;

public class ReviewState implements State{

	private Document d;
	
	



	public void setDocument(Document d) {
		this.d = d;
	}



	@Override
	public void advance() {
		System.out.println("Moving to approved");
		State state = new ApprovedState();
		d.changeState(state);
	}



	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Review";
	}
	
	

}
