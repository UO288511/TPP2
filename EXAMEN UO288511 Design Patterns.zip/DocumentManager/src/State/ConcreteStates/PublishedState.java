package State.ConcreteStates;

import State.Document;
import State.State;

public class PublishedState implements State{

private Document d;
	
	public void setDocument(Document d) {
		this.d = d;
	}
	
	@Override
	public void advance() {
		System.out.println("Published and finisehed");
		
		
	}

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Published";
	}

}
