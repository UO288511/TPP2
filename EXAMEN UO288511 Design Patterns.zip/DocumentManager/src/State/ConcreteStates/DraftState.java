package State.ConcreteStates;

import State.Document;
import State.State;

public class DraftState implements State{
	
	private Document d;
	

	

	public void setDocument(Document d) {
		this.d = d;
	}

	

	@Override
	public void advance() {
				System.out.println("Moving to REVIEW");
				State s = new ReviewState();
				d.changeState(s);
				
	}



	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Draft";
	}

}
