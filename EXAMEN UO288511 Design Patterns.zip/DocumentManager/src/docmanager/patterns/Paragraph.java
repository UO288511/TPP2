package docmanager.patterns;

import Composite.Component;

public class Paragraph implements Component{
	private String text;

	public Paragraph(String text) {
		this.text = text;
	}

	public void print() {
		System.out.println(text);
	}

	@Override
	public void execute() {
		print();
	}
}
