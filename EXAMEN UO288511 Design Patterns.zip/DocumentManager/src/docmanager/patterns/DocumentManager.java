package docmanager.patterns;

import java.util.ArrayList;
import java.util.List;

public class DocumentManager {
	private List<Document> documents = new ArrayList<Document>();
	public DocumentManager instance;

	public void addDocument(Document d) {
		documents.add(d);
	}

	public void printAll() {
		for (Document d : documents) {
			d.print();
		}
	}
	
	public DocumentManager() {
		
	}
	
	public DocumentManager getInstance() {
		if (instance==null) {
			instance = new DocumentManager();
		}
		return instance;
	}
}
