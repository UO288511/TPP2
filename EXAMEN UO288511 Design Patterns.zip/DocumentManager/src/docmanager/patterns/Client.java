package docmanager.patterns;




public class Client {

	public static void main(String[] args) {
		DocumentManager manager1 = new DocumentManager();
		manager1.getInstance();

		Document doc = new Document("Report");
		Section s1 = new Section("Intro");
		Section s2 = new Section("Conclusion");
		s1.add(new Paragraph("This is the intro paragraph. This doc is very cool."));
		s2.add(new Paragraph("This is the conclusion paragraph. That's all, folks."));
		doc.add(s1);
		doc.add(s2);

		manager1.addDocument(doc);

		/*doc.review();
		doc.approve();
		doc.publish();*/

		manager1.printAll();
	}
}
