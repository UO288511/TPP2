package docmanager.patterns;

import java.util.ArrayList;
import java.util.List;

import Composite.Component;

public class Section implements Component{

	private String title;

	private List<Component> components = new ArrayList<Component>();

	public Section(String title) {
		this.title = title;
	}

	

	public void add(Component c) {
		components.add(c);
	}
	

	public void remove(Component c) {
		components.remove(c);
	}

	@Override
	public void execute() {
		System.out.println("Section" + title);
		for (Component c: components) {
			c.toString();
		}
	}

	public Section(List<Component> components) {
		super();
		this.components = components;
	}


	@Override
	public String toString() {
		return "Section [title=" + title + ", components=" + components + "]";
	}
	
	
}
