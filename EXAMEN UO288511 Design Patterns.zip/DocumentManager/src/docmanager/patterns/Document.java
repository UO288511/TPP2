package docmanager.patterns;

import java.util.ArrayList;
import java.util.List;

import State.State;
import State.ConcreteStates.DraftState;

public class Document {
	private String name;
	private List<Section> sections = new ArrayList<Section>();
	private State state ;

	public Document(String name) {
		this.name = name;
		
	}

	public void add(Section s) {
		sections.add(s);
	}

	public void print() {
		System.out.println("Document: " + name);
		for (Section s : sections) {
			System.out.println(s);
		}
	}
	
	public Document(State initialState) {
		super();
		initialState=new DraftState();
		this.state=initialState;
	}
	
	public void changeState(State state1) {
		this.state=state1;
	}
	
	public void advance() {
		state.advance();
	}

	/*public void review() {
		if (state.equals("DRAFT")) {
			System.out.println("Moving to REVIEW");
			state = "REVIEW";
		} else {
			System.out.println("Cannot move to review from " + state);
		}
	}

	public void approve() {
		if (state.equals("REVIEW")) {
			System.out.println("Approved");
			state = "APPROVED";
		} else {
			System.out.println("Cannot approve from " + state);
		}
	}

	public void publish() {
		if (state.equals("APPROVED")) {
			System.out.println("Published!");
			state = "PUBLISHED";
		} else {
			System.out.println("Cannot publish from " + state);
		}
	}*/
}
